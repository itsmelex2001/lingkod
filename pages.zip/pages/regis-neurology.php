<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Patient Registration</title>
    <link rel="stylesheet" href="/sdn/public/css/global.css?v=9" />
    <link rel="stylesheet" href="/sdn/public/css/navigation.css?v=9" />
    <link rel="stylesheet" href="/sdn/public/css/forms.css" />
    <link rel="stylesheet" href="/sdn/public/css/modal-export.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
  </head>
  <body>
    <div style="max-width: 1000px; width: 90%; margin: 2rem auto 0;">
      <?php
      if (isset($_GET['source']) && $_GET['source'] === 'home') {
          $backUrl = '/sdn/index.php';
      } elseif (isset($_GET['source']) && $_GET['source'] === 'schedules') {
          $backUrl = '/sdn/pages/schedules.php';
      } else {
          $backUrl = '/sdn/pages/department-select.php';
      }
      ?>
      <a href="<?= htmlspecialchars($backUrl) ?>" class="btn-back">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </a>
    </div>
    <div class="registration-container" style="margin-top: 1rem;">
      <h2>Neurology Registration</h2>

      <form id="regForm">
        <input type="hidden" id="department" value="neurology" />

        <div class="form-section">
          <h3>Personal Information</h3>
          <div class="grid-row">
            <div class="form-group">
              <label>Full Name <span class="asterisk">*</span></label>
              <input id="fullName" type="text" placeholder="Enter full name" maxlength="100" required />
            </div>
            <div class="form-group">
              <label>HRN</label>
              <input type="text" id="hrn" placeholder="Auto-generated" readonly />
            </div>
          </div>

          <div class="grid-row">
            <div class="form-group">
              <label>Gender <span class="asterisk">*</span></label>
              <select id="gender" required>
                <option value="" disabled selected>Select gender...</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
            </div>
          </div>

          <div class="grid-row">
            <div class="form-group">
              <label>Birthdate <span class="asterisk">*</span></label>
              <input type="date" id="birthdate" max="<?= date('Y-m-d') ?>" required />
            </div>
            <div class="form-group">
              <label>Age</label>
              <input type="number" id="age" placeholder="Age" readonly />
            </div>
          </div>

          <div class="grid-row">
            <div class="form-group">
              <label>Contact Number <span class="asterisk">*</span></label>
              <input id="contactNumber" type="tel" placeholder="09XXXXXXXXX" pattern="^(09|\+639)\d{9}$" maxlength="13" title="Format: 09XXXXXXXXX or +639XXXXXXXXX" required />
            </div>
            <div class="form-group">
              <label>Email Address</label>
              <input id="emailAddress" type="email" placeholder="Optional" maxlength="100" />
            </div>
          </div>

          <div class="form-group">
            <label>Complete Address <span class="asterisk">*</span></label>
            <input id="address" type="text" placeholder="Enter full address" maxlength="255" required />
          </div>

          <div class="form-group">
            <label>Is there anyone else accompanying the patient? <span class="asterisk">*</span></label>
            <div class="radio-group">
              <label><input type="radio" name="companion" value="yes" /> Yes</label>
              <label><input type="radio" name="companion" value="no" checked /> No</label>
            </div>
          </div>
        </div>

        <div class="form-section">
          <h3>Medical Information</h3>
          <div class="form-group">
            <label>Health Concerns <span class="asterisk">*</span></label>
            <textarea id="chiefComplaints" placeholder="Describe main symptoms" rows="3" required></textarea>
          </div>

          <div class="form-group">
            <label>Nature of Consultation <span class="asterisk">*</span></label>
            <select id="consultationAbout" required>
              <option value="" disabled selected>Select nature of consultation...</option>
              <option>Follow-up Checkup</option>
              <option>Initial Evaluation</option>
              <option>Laboratory Results Review</option>
              <option>Medication Refill</option>
            </select>
          </div>

          <div class="form-group">
            <label>Brief description of the disease/illness or symptoms</label>
            <textarea id="illnessDescription" placeholder="Optional" rows="3"></textarea>
          </div>
        </div>

        <div class="form-section">
          <h3>Appointment Details</h3>
          <div class="grid-row">
            <div class="form-group">
              <label>Type of Client <span class="asterisk">*</span></label>
              <select id="patientType" required>
                <option value="" disabled selected>Select client type...</option>
                <option value="first-time">First Time Patient</option>
                <option value="returning">Returning Patient</option>
              </select>
            </div>
            <div class="form-group">
              <label>Type of Appointment <span class="asterisk">*</span></label>
              <select id="appointmentType" required>
                <option value="" disabled selected>Select appointment type...</option>
                <option value="walk-in">Walk-in</option>
                <option value="online">Online</option>
              </select>
            </div>
          </div>

          <div class="grid-row">
            <div class="form-group">
              <label>Consultation Mode <span class="asterisk">*</span></label>
              <select id="consultationMode" required>
                <option value="" disabled selected>Select mode...</option>
                <option>Face-to-Face</option>
                <option>E-consultation</option>
              </select>
            </div>
            <div class="form-group">
              <label>Appointment Date <span class="asterisk">*</span></label>
              <input type="date" id="appointmentDate" min="<?= date('Y-m-d') ?>" required />
            </div>
            <div class="form-group">
              <label>Appointment Time <span class="asterisk">*</span></label>
              <input type="time" id="appointmentTime" required />
            </div>
          </div>

          <div class="form-group">
            <label>Referral Source</label>
            <input id="referralSource" type="text" placeholder="Optional" />
          </div>
        </div>

        <p class="required-legend"><span class="asterisk">*</span> Indicates a required field</p>
        <button type="submit" class="btn-submit">Confirm</button>
      </form>
    </div>

    <div id="summaryModal" class="modal-overlay">
      <div class="modal-box">
        <div id="printArea">
          <div class="print-header">
            <div class="print-header-inner">
              <div class="print-header-badge">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
              </div>
              <div class="print-header-content">
                <h1 class="print-clinic-name">Patient Registration Form</h1>
                <div class="print-meta-row">
                  <p class="print-ref">Ref No: <strong id="refNumber"></strong></p>
                  <span class="print-meta-sep">·</span>
                  <p class="print-date">Submitted: <strong id="submittedDate"></strong></p>
                </div>
              </div>
            </div>
          </div>

          <div class="print-body">
            <div class="print-section">
              <div class="print-section-title">Department</div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Selected Department</span>
                  <span class="print-value" id="p-department"></span>
                </div>
              </div>
            </div>

            <div class="print-section">
              <div class="print-section-title">Personal Information</div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Full Name</span>
                  <span class="print-value" id="p-fullName"></span>
                </div>
                <div class="print-field">
                  <span class="print-label">Gender</span>
                  <span class="print-value" id="p-gender"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Birthdate</span>
                  <span class="print-value" id="p-birthdate"></span>
                </div>
                <div class="print-field">
                  <span class="print-label">Age</span>
                  <span class="print-value" id="p-age"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Contact Number</span>
                  <span class="print-value" id="p-contact"></span>
                </div>
                <div class="print-field">
                  <span class="print-label">Email</span>
                  <span class="print-value" id="p-email"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field full">
                  <span class="print-label">Address</span>
                  <span class="print-value" id="p-address"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">With Companion?</span>
                  <span class="print-value" id="p-companion"></span>
                </div>
              </div>
            </div>

            <div class="print-section">
              <div class="print-section-title">Medical Information</div>
              <div class="print-row">
                <div class="print-field full">
                  <span class="print-label">Health Concerns</span>
                  <span class="print-value" id="p-complaints"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Nature of Consultation</span>
                  <span class="print-value" id="p-consultation"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field full">
                  <span class="print-label">Illness Description</span>
                  <span class="print-value" id="p-illness"></span>
                </div>
              </div>
            </div>

            <div class="print-section">
              <div class="print-section-title">Appointment Details</div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Type of Client</span>
                  <span class="print-value" id="p-patientType"></span>
                </div>
                <div class="print-field">
                  <span class="print-label">Type of Appointment</span>
                  <span class="print-value" id="p-appointmentType"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Consultation Mode</span>
                  <span class="print-value" id="p-mode"></span>
                </div>
                <div class="print-field">
                  <span class="print-label">Appointment Date</span>
                  <span class="print-value" id="p-appointmentDate"></span>
                </div>
              </div>
              <div class="print-row">
                <div class="print-field">
                  <span class="print-label">Referral Source</span>
                  <span class="print-value" id="p-referral"></span>
                </div>
              </div>
            </div>

            <div class="print-footer-note">
              This registration form is for medical facility use only. Please present this document upon arrival.
            </div>
          </div>
        </div>

        <div class="modal-actions no-print">
          <div class="modal-optional-row">
            <span class="modal-optional-label">Optional — save a copy</span>
            <div class="modal-optional-btns">
              <button id="btnDownloadPDF" class="btn-export">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Download PDF
              </button>
              <button id="btnPrint" class="btn-export">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                Print
              </button>
            </div>
          </div>

          <button id="btnClose" class="btn-confirm-close">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            Confirm
          </button>
        </div>

      </div>
    </div>

    <div id="successToast" class="success-toast">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="20 6 9 17 4 12"/></svg>
      <div>
        <strong>Registration Confirmed!</strong>
        <span>Your registration has been successfully submitted.</span>
      </div>
    </div>

    <div id="pdfContainer">
      <div id="pdf-header">
        <div class="pdf-header-logo">+</div>
        <div>
          <div class="pdf-header-title">Patient Registration Form</div>
          <div class="pdf-header-meta">Reference No: <strong id="pdf-refNumber"></strong></div>
          <div class="pdf-header-meta">Date Submitted: <strong id="pdf-submittedDate"></strong></div>
        </div>
      </div>

      <div class="pdf-body-padding">
        <div class="pdf-section">
          <div class="pdf-section-title">Department</div>
          <div class="pdf-row">
            <div class="pdf-field full">
              <div class="pdf-label">Selected Department</div>
              <div class="pdf-value" id="pdf-department"></div>
            </div>
          </div>
        </div>

        <div class="pdf-section">
          <div class="pdf-section-title">Personal Information</div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Full Name</div>
              <div class="pdf-value" id="pdf-fullName"></div>
            </div>
            <div class="pdf-field">
              <div class="pdf-label">Gender</div>
              <div class="pdf-value" id="pdf-gender"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Birthdate</div>
              <div class="pdf-value" id="pdf-birthdate"></div>
            </div>
            <div class="pdf-field">
              <div class="pdf-label">Age</div>
              <div class="pdf-value" id="pdf-age"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Contact Number</div>
              <div class="pdf-value" id="pdf-contact"></div>
            </div>
            <div class="pdf-field">
              <div class="pdf-label">Email Address</div>
              <div class="pdf-value" id="pdf-email"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field full">
              <div class="pdf-label">Complete Address</div>
              <div class="pdf-value" id="pdf-address"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">With Companion?</div>
              <div class="pdf-value" id="pdf-companion"></div>
            </div>
          </div>
        </div>

        <div class="pdf-section">
          <div class="pdf-section-title">Medical Information</div>
          <div class="pdf-row">
            <div class="pdf-field full">
              <div class="pdf-label">Chief Complaints</div>
              <div class="pdf-value" id="pdf-complaints"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Nature of Consultation</div>
              <div class="pdf-value" id="pdf-consultation"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field full">
              <div class="pdf-label">Illness Description</div>
              <div class="pdf-value" id="pdf-illness"></div>
            </div>
          </div>
        </div>

        <div class="pdf-section">
          <div class="pdf-section-title">Appointment Details</div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Type of Client</div>
              <div class="pdf-value" id="pdf-patientType"></div>
            </div>
            <div class="pdf-field">
              <div class="pdf-label">Type of Appointment</div>
              <div class="pdf-value" id="pdf-appointmentType"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Consultation Mode</div>
              <div class="pdf-value" id="pdf-mode"></div>
            </div>
            <div class="pdf-field">
              <div class="pdf-label">Appointment Date</div>
              <div class="pdf-value" id="pdf-appointmentDate"></div>
            </div>
          </div>
          <div class="pdf-row">
            <div class="pdf-field">
              <div class="pdf-label">Referral Source</div>
              <div class="pdf-value" id="pdf-referral"></div>
            </div>
          </div>
        </div>

        <div class="pdf-signature-table">
          <div class="pdf-signature-row">
            <div class="pdf-signature-cell">
              <div class="pdf-signature-line"></div>
              <div class="pdf-signature-label">Patient / Guardian Signature</div>
            </div>
            <div class="pdf-signature-cell">
              <div class="pdf-signature-line"></div>
              <div class="pdf-signature-label">Staff on Duty</div>
            </div>
            <div class="pdf-signature-cell">
              <div class="pdf-signature-line"></div>
              <div class="pdf-signature-label">Date & Time Received</div>
            </div>
          </div>
        </div>

        <div class="pdf-footer-note-text">
          This registration form is for medical facility use only. Please present this document upon arrival.
        </div>
      </div>
    </div>

    <script src="/sdn/public/js/utils.js"></script>
    <script src="/sdn/public/js/navigation.js"></script>
    <script src="/sdn/public/js/print-pdf-setup.js"></script>
    <script src="/sdn/public/js/regis-neurology.js"></script>
    <script src="/sdn/public/js/modal-export.js"></script>
  </body>
</html>
